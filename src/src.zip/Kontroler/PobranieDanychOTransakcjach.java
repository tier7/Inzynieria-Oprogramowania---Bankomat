package Kontroler;


import Model.IModel;

public class PobranieDanychOTransakcjach {

	private IModel model;
	private String zakresDat;
	private String typOperacji;
	private String[] listaWynikowa;
	private IStrategiaEksportu strategiaEksportu;

	/**
	 * 
	 * @param model
	 */
	public void PobieranieDanychOTransakcjach(IModel model) {
		// TODO - implement PobranieDanychOTransakcjach.PobieranieDanychOTransakcjach
		throw new UnsupportedOperationException();
	}

	public void wprowadzenieZakresuDat() {
		// TODO - implement PobranieDanychOTransakcjach.wprowadzenieZakresuDat
		throw new UnsupportedOperationException();
	}

	public void wprowadzenieTypuOperacji() {
		// TODO - implement PobranieDanychOTransakcjach.wprowadzenieTypuOperacji
		throw new UnsupportedOperationException();
	}

	public String[] pobranieListyOperacji() {
		// TODO - implement PobranieDanychOTransakcjach.pobranieListyOperacji
		throw new UnsupportedOperationException();
	}

	public void filtrowanieDanych() {
		// TODO - implement PobranieDanychOTransakcjach.filtrowanieDanych
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param opcja
	 */
	public void eksportDanych(int opcja) {
		// TODO - implement PobranieDanychOTransakcjach.eksportDanych
		throw new UnsupportedOperationException();
	}

}