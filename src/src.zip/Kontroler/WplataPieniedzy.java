package Kontroler;


import Model.IModel;

public class WplataPieniedzy {

	private IModel model;
	private int deklarowanaKwota;
	private int wartoscBanknotow;
	private boolean potwierdzenie;
	private int nrKarty;
	private boolean czyMiejsceWBankomacie;

	/**
	 * 
	 * @param model
	 * @param nrKarty
	 */
	public WplataPieniedzy(IModel model, int nrKarty) {
		this.model = model;
		this.nrKarty = nrKarty;
		this.deklarowanaKwota = 0;
		this.wartoscBanknotow = 0;
		this.potwierdzenie = false;
		this.czyMiejsceWBankomacie = false;

		throw new UnsupportedOperationException();
	}

	public void wprowadzenieKwoty(int kwota) {
		if (kwota <= 0){
			throw new UnsupportedOperationException();
		}
		else {
			this.deklarowanaKwota = kwota;
		}
	}

	public void weryfikacjaZawartosciGotowki() {
		//int iloscWprowadzonychBanknotow = obliczIloscWprowadzonychBanknotow()

	}

	public int przeliczenieWartosciBanknotow() {
		return this.deklarowanaKwota;
	}

	public boolean porownanieKwot() {
		// TODO - implement Wp�ataPieni�dzy.por�wnanieKwot
		throw new UnsupportedOperationException();
	}

	public void wyborPotwierdzenia() {
		// TODO - implement Wp�ataPieni�dzy.wyb�rPotwierdzenia
		throw new UnsupportedOperationException();
	}

	public void weryfikacjaPrzezSystemBankowy() {
		// TODO - implement Wp�ataPieni�dzy.weryfikacjaPrzezSystemBankowy
		throw new UnsupportedOperationException();
	}

}