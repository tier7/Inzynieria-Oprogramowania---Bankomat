package Kontroler;

public interface IKontrolerKlienta {

	void wykonaniePrzelewu();

	void sprawdzenieStanuKonta();

	void wplataPieniedzy();

	void wyplataPieniedzy();

	void uwierzytelnianieKlienta(int nrKarty, int pin, int kwota);

}