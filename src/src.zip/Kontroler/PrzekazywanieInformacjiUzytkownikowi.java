package Kontroler;


public class PrzekazywanieInformacjiUzytkownikowi {

	/**
	 * 
	 * @param komunikat
	 */
	public void przekazanieInformacji(String komunikat) {
		// TODO - implement PrzekazywanieInformacjiU?ytkownikowi.przekazanieInformacji
		throw new UnsupportedOperationException();
	}

}