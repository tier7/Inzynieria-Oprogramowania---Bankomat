package Kontroler;


import Model.IModel;

public class WyswietlenieNaEkranie extends IStrategiaEksportu {

	/**
	 * 
	 * @param model
	 */
	public WyswietlenieNaEkranie(IModel model) {
		// TODO - implement WyswietlenieNaEkranie.WyswietlenieNaEkranie
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dane
	 */
	public void eksportDanych(String[] dane) {
		// TODO - implement WyswietlenieNaEkranie.eksportDanych
		throw new UnsupportedOperationException();
	}

}