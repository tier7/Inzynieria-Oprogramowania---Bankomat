package Kontroler;


import Model.IModel;

public abstract class IStrategiaEksportu {

	protected IModel model;

	/**
	 * 
	 * @param dane
	 */
	public abstract void eksportDanych(String[] dane);

}