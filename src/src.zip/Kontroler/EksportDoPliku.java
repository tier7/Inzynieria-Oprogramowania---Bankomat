package Kontroler;

import Model.IModel;

public class EksportDoPliku extends IStrategiaEksportu {

	protected String nazwaPliku;

	/**
	 * 
	 * @param model
	 */
	public EksportDoPliku(IModel model) {
		// TODO - implement EksportDoPliku.EksportDoPliku
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dane
	 */
	public void eksportDanych(String[] dane) {
		// TODO - implement EksportDoPliku.eksportDanych
		throw new UnsupportedOperationException();
	}

}