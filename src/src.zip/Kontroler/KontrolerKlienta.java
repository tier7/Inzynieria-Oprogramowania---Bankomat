package Kontroler;


import Model.IModel;

public class KontrolerKlienta implements IKontrolerKlienta {

	private IModel model;
	public KontrolerKlienta(IModel model) {
		this.model = model;
	}

	public void wplataPieniedzy() {
		int nrKarty = 111111;
		WplataPieniedzy pu2 = new WplataPieniedzy(this.model, nrKarty);
	}

	public void wykonaniePrzelewu() {
		// TODO - implement KontrolerKlienta.wykonaniePrzelewu
		throw new UnsupportedOperationException();
	}

	public void sprawdzenieStanuKonta() {
		// TODO - implement KontrolerKlienta.sprawdzenieStanuKonta
		throw new UnsupportedOperationException();
	}

	public void wyplataPieniedzy() {
		// TODO - implement KontrolerKlienta.wyplataPieniedzy
		throw new UnsupportedOperationException();
	}

	public void uwierzytelnianieKlienta(int nrKarty, int pin, int kwota) {
		// TODO - implement KontrolerKlienta.uwierzytelnianieKlienta
		throw new UnsupportedOperationException();
	}

	public void operation() {
		// TODO - implement KontrolerKlienta.operation
		throw new UnsupportedOperationException();
	}

}