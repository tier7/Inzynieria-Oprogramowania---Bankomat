package Kontroler;

import Model.*;
import java.util.HashMap;
import java.util.Map;

public class SystemZarządzaniaBankomatem {
	public static void main(String[] args) {

		Map<Integer, Integer> startowyStanGotowki = new HashMap<>();
		startowyStanGotowki.put(100, 50);
		startowyStanGotowki.put(50, 100);

		IDAO dao = new DAO();
		Sejf sejf = new Sejf(startowyStanGotowki);
		RejestrTransakcji rejestr = new RejestrTransakcji(dao);
		IModel model = new Model(dao, rejestr, sejf);

		IKontrolerKlienta kontrolerKlienta = new KontrolerKlienta(model);
		IKontrolerPracownika kontrolerPracownika = new KontrolerPracownika(model);

		System.out.println("\nSystem Zarządzania Bankomatem");
		
	}
}
