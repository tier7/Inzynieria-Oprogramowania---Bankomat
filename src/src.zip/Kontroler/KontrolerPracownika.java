package Kontroler;


import Model.IModel;

public class KontrolerPracownika implements IKontrolerPracownika {

	private IModel model;
	public KontrolerPracownika(IModel model) {
		this.model = model;
	}
	public void aktualizacjaZawartosciGotowki() {
		// TODO - implement KontrolerPracownika.aktualizacjaZawartosciGotowki
		throw new UnsupportedOperationException();
	}

	public void pobranieDanychOTransakcjach() {
		// TODO - implement KontrolerPracownika.pobranieDanychOTransakcjach
		throw new UnsupportedOperationException();
	}

	public void uwierzytelnianiePracownika(int nrKarty, int pin) {
		// TODO - implement KontrolerPracownika.uwierzytelnianiePracownika
		throw new UnsupportedOperationException();
	}

}