package Kontroler;

public class DrukowaniePotwierdzenia {

	private String dataIGodzina;
	private int nrKonta;
	private String daneKlienta;
	private int stanKontaPrzed;
	private int stanKontaPo;
	private String rodzajOperacji;
	private String tytulPrzelewu;
	private int nrKontaAdresata;
	private String nazwaAdresata;
	private String typOperacji;

	/**
	 * 
	 * @param data
	 * @param nrKonta
	 * @param daneKlienta
	 */
	public DrukowaniePotwierdzenia(String data, int nrKonta, String daneKlienta, int stanKontaPrzed, int stanKontaPo,
								   String rodzajOperacji, String tytulPrzelewu, int nrKontaAdresata, String nazwaAdresata, String typOperacji) {

		// TODO - implement DrukowaniePotwierdzenia.DrukowaniePotwierdzenia
		throw new UnsupportedOperationException();
	}

	public void drukowanie() {
		// TODO - implement DrukowaniePotwierdzenia.drukowanie
		throw new UnsupportedOperationException();
	}

}