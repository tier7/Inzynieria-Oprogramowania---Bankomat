package Kontroler;

public interface IKontrolerPracownika {

	void aktualizacjaZawartosciGotowki();

	void pobranieDanychOTransakcjach();

	void uwierzytelnianiePracownika(int nrKarty, int pin);

}