package Model;

import java.util.*;

public class RejestrTransakcji {

	private IDAO dao;
	private IFabrykaTransakcji fabryka;
	private Collection<ITransakcja> transakcje;
	private Sejf sejf;
	private Collection<Klient> klienci;

	/**
	 * 
	 * @param dao
	 */
	public RejestrTransakcji(IDAO dao) {
		// TODO - implement RejestrTransakcji.RejestrTransakcji

	}

	public ITransakcja pobranieWszystkichTransakcji() {
		// TODO - implement RejestrTransakcji.pobranieWszystkichTransakcji
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param transakcja
	 */
	public void zapisTransakcji(ITransakcja transakcja) {
		// TODO - implement RejestrTransakcji.zapisTransakcji
		throw new UnsupportedOperationException();
	}

}