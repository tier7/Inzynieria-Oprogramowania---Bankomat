package Model;

public class TransakcjaZPotwierdzeniem extends DekoratorTransakcji {

	private int stanKontaPrzed;
	private int stanKontaPo;
	private String daneKlienta;

	/**
	 * 
	 * @param transakcja
	 * @param stanPrzed
	 * @param stanPo
	 * @param klient
	 */
	public TransakcjaZPotwierdzeniem(ITransakcja transakcja, int stanPrzed, int stanPo, String klient) {
        // TODO - implement TransakcjaZPotwierdzeniem.TransakcjaZPotwierdzeniem
		super(transakcja);
		throw new UnsupportedOperationException();
	}

	public String pobranieDanych() {
		// TODO - implement TransakcjaZPotwierdzeniem.pobranieDanych
		throw new UnsupportedOperationException();
	}

}