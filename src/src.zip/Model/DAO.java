package Model;

public class DAO implements IDAO {

	public DAO() {
		// TODO - implement DAO.DAO
	}

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	public boolean uwierzytelnienieKlienta(int nrKarty, int pin) {
		// TODO - implement DAO.uwierzytelnienieKlienta
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	public void uwierzytelnieniePracownika(int nrKarty, int pin) {
		// TODO - implement DAO.uwierzytelnieniePracownika
		throw new UnsupportedOperationException();
	}

	public int pobranieStanuGotowki() {
		// TODO - implement DAO.pobranieStanuGot�wki
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param kwota
	 */
	public void aktualizacjaStanuGotowki(int kwota) {
		// TODO - implement DAO.aktualizacjaStanuGot�wki
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dane
	 */
	public boolean zaksiegowanieOperacji(String dane) {
		// TODO - implement DAO.zaksi�gowanieOperacji
		throw new UnsupportedOperationException();
	}

	public String[] pobranieLogow() {
		// TODO - implement DAO.pobranieLog�w
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param informacje
	 */
	public void zapisanieLogow(String informacje) {
		// TODO - implement DAO.zapisanieLog�w
		throw new UnsupportedOperationException();
	}

}