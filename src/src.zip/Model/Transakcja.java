package Model;

public class Transakcja implements ITransakcja {

	private String dataIGodzina;
	private String typOperacji;
	private int kwota;
	private int nrKontaNadawcy;
	private String tytulPrzelewu;
	private int nrKontaAdresata;
	private String nazwaAdresata;

	/**
	 * 
	 * @param data
	 * @param typ
	 * @param kwota
	 * @param nadawca
	 * @param tytul
	 */
	public Transakcja(String data, String typ, int kwota, int nadawca, String tytul) {
		// TODO - implement Transakcja.Transakcja
		throw new UnsupportedOperationException();
	}

	public String pobranieDanych() {
		// TODO - implement Transakcja.pobranieDanych
		throw new UnsupportedOperationException();
	}

}