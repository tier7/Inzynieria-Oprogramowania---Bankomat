package Model;

public interface ITransakcja {

	String pobranieDanych();

}