package Model;

public class Model implements IModel {

	private IDAO dao;
	private RejestrTransakcji rejestr;
	private Sejf sejf;

	public Model(IDAO dao, RejestrTransakcji rejestr, Sejf sejf) {
		this.dao = dao;
		this.rejestr = rejestr;
		this.sejf = sejf;
	}
	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	public boolean logowanieKlient(int nrKarty, int pin) {
		// TODO - implement Model.logowanieKlient
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	public boolean logowaniePracownik(int nrKarty, int pin) {
		// TODO - implement Model.logowaniePracownik
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param kwota
	 */
	public boolean sprawdzenieMiejscaNaGotowke(int kwota) {
		// TODO - implement Model.sprawdzenieMiejscaNaGotowke
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param kwota
	 * @param nrKarty
	 */
	public boolean weryfikacjaTransakcjiWBanku(int kwota, int nrKarty) {
		// TODO - implement Model.weryfikacjaTransakcjiWBanku
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param kwota
	 * @param nrKarty
	 * @param potwierdzenie
	 */
	public void ksiegowanieWplaty(int kwota, int nrKarty, boolean potwierdzenie) {
		// TODO - implement Model.ksi�gowanieWp�aty
		throw new UnsupportedOperationException();
	}

	public String[] pobranieWszystkichTransakcji() {
		// TODO - implement Model.pobranieWszystkichTransakcji
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param informacje
	 */
	public void rejestracjaZdarzenia(String informacje) {
		// TODO - implement Model.rejestracjaZdarzenia
		throw new UnsupportedOperationException();
	}

}