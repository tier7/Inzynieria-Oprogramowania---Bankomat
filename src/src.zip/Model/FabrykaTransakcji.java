package Model;

public class FabrykaTransakcji implements IFabrykaTransakcji {

	/**
	 * 
	 * @param dane
	 */
	public ITransakcja utworzenieTransakcji(String dane) {
		// TODO - implement FabrykaTransakcji.utworzenieTransakcji
		throw new UnsupportedOperationException();
	}

}