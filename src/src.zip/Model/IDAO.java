package Model;

public interface IDAO {

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	boolean uwierzytelnienieKlienta(int nrKarty, int pin);

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	void uwierzytelnieniePracownika(int nrKarty, int pin);

	int pobranieStanuGotowki();

	/**
	 * 
	 * @param kwota
	 */
	void aktualizacjaStanuGotowki(int kwota);

	/**
	 * 
	 * @param dane
	 */
	boolean zaksiegowanieOperacji(String dane);

	String[] pobranieLogow();

	/**
	 * 
	 * @param informacje
	 */
	void zapisanieLogow(String informacje);

}