package Model;

public interface IFabrykaTransakcji {

	/**
	 * 
	 * @param dane
	 */
	ITransakcja utworzenieTransakcji(String dane);

}