package Model;

public abstract class DekoratorTransakcji implements ITransakcja {

	protected ITransakcja transakcja;

	/**
	 * 
	 * @param transakcja
	 */
	public DekoratorTransakcji(ITransakcja transakcja) {
		// TODO - implement DekoratorTransakcji.DekoratorTransakcji
		throw new UnsupportedOperationException();
	}

	public String pobranieDanych() {
		// TODO - implement DekoratorTransakcji.pobranieDanych
		throw new UnsupportedOperationException();
	}

}