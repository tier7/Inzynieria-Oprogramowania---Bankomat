package Model;

public class Klient {

	private int nrKarty;
	private int pin;
	private String imie;
	private String nazwisko;
	private String saldo;

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 * @param imie
	 * @param nazwisko
	 * @param saldo
	 */
	public Klient(int nrKarty, int pin, String imie, String nazwisko, int saldo) {
		// TODO - implement Klient.Klient
		throw new UnsupportedOperationException();
	}

	public String pobranieDanych() {
		// TODO - implement Klient.pobranieDanych
		throw new UnsupportedOperationException();
	}

}