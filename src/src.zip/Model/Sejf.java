package Model;

import java.util.Map;

public class Sejf {

	private Map<Integer, Integer> banknoty;
	private int iloscBanknotow;
	private int limitPojemnosci;

	/**
	 * 
	 * @param banknoty
	 */
	public Sejf(Map banknoty) {
		// TODO - implement Sejf.Sejf

	}

	/**
	 * 
	 * @param iloscBanknotow
	 */
	public boolean czyMiejsce(int iloscBanknotow) {
		// TODO - implement Sejf.czyMiejsce
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param kwota
	 */
	public boolean czySaNominaly(int kwota) {
		// TODO - implement Sejf.czyS�Nomina�y
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param banknoty
	 */
	public void aktualizacjaStanu(Map banknoty) {
		// TODO - implement Sejf.aktualizacjaStanu
		throw new UnsupportedOperationException();
	}

}