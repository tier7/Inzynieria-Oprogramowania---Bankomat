package Model;

public interface IModel {

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	boolean logowanieKlient(int nrKarty, int pin);

	/**
	 * 
	 * @param nrKarty
	 * @param pin
	 */
	boolean logowaniePracownik(int nrKarty, int pin);

	/**
	 * 
	 * @param kwota
	 * @param nrKarty
	 */
	boolean weryfikacjaTransakcjiWBanku(int kwota, int nrKarty);

	/**
	 * 
	 * @param kwota
	 * @param nrKarty
	 * @param potwierdzenie
	 */
	void ksiegowanieWplaty(int kwota, int nrKarty, boolean potwierdzenie);

	String[] pobranieWszystkichTransakcji();

	/**
	 * 
	 * @param informacje
	 */
	void rejestracjaZdarzenia(String informacje);

}